import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud, STOPWORDS
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, SpatialDropout1D, Bidirectional
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import re
from PIL import Image

# Add a fun image
st.image('https://png.pngtree.com/element_our/20190601/ourlarge/pngtree-white-movie-icon-image_1344876.jpg', width=300)


# Download necessary NLTK data
nltk.download('stopwords')
nltk.download('wordnet')

# Set up the Streamlit app
st.title('🎬 IMDB Reviews Sentiment Analysis Dashboard')
st.write("This application allows you to explore IMDB reviews, train a sentiment analysis model, and make predictions. 📊")

# Load data
@st.cache_data
def load_data():
    df = pd.read_csv('https://raw.githubusercontent.com/jinniekyo/IMDB-reviews/main/IMDB.csv')
    return df

data = load_data()

# Display the data
st.subheader('📋 Raw Data')
st.write("Here is a preview of the raw data:")
st.write(data.head())

# Add a fun image
st.image('https://i.imgur.com/pQWQfYH.jpg', use_column_width=True)

# Data preprocessing
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\b\w{1,2}\b', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

data['review'] = data['review'].apply(preprocess_text)

# Display word cloud
st.subheader('☁️ Word Cloud')
st.write("Word cloud of the most common words in the reviews:")
all_words = ' '.join([text for text in data['review']])
wordcloud = WordCloud(width=800, height=500, random_state=21, max_font_size=110, stopwords=STOPWORDS).generate(all_words)
plt.figure(figsize=(10, 7))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis('off')
st.pyplot(plt)

# Prepare data for model
st.subheader('🛠 Data Preparation')
st.write("Preparing the data for training...")

tokenizer = Tokenizer(num_words=5000, split=' ')
tokenizer.fit_on_texts(data['review'].values)
X = tokenizer.texts_to_sequences(data['review'].values)
X = pad_sequences(X)
Y = pd.get_dummies(data['sentiment']).values

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)
st.write("Data preparation completed. ✅")

# Build LSTM model
st.subheader('🏗 Model Building')
st.write("Building and compiling the LSTM model...")

model = Sequential()
model.add(Embedding(5000, 100, input_length=X.shape[1]))
model.add(SpatialDropout1D(0.2))
model.add(Bidirectional(LSTM(100, dropout=0.2, recurrent_dropout=0.2)))
model.add(Dense(2, activation='softmax'))
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
st.write("Model building completed. 🏁")

# Train model
if st.button('Train model'):
    st.subheader('🔄 Model Training')
    with st.spinner('Training the model, please wait...'):
        history = model.fit(X_train, Y_train, epochs=5, batch_size=64, validation_split=0.1)
        st.success('Model trained! 🎉')
        
        # Plot training & validation accuracy values
        fig, ax = plt.subplots()
        ax.plot(history.history['accuracy'])
        ax.plot(history.history['val_accuracy'])
        ax.set_title('Model Accuracy')
        ax.set_ylabel('Accuracy')
        ax.set_xlabel('Epoch')
        ax.legend(['Train', 'Validation'], loc='upper left')
        st.pyplot(fig)
        
        # Plot training & validation loss values
        fig, ax = plt.subplots()
        ax.plot(history.history['loss'])
        ax.plot(history.history['val_loss'])
        ax.set_title('Model Loss')
        ax.set_ylabel('Loss')
        ax.set_xlabel('Epoch')
        ax.legend(['Train', 'Validation'], loc='upper left')
        st.pyplot(fig)

# Evaluate model
if st.button('Evaluate model'):
    st.subheader('🔍 Model Evaluation')
    predictions = model.predict(X_test)
    predictions = np.argmax(predictions, axis=1)
    Y_test_labels = np.argmax(Y_test, axis=1)
    accuracy = accuracy_score(Y_test_labels, predictions)
    st.write(f'Accuracy: {accuracy * 100:.2f}%')
    
    # Display confusion matrix
    cm = confusion_matrix(Y_test_labels, predictions)
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax)
    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    ax.set_title('Confusion Matrix')
    st.pyplot(fig)
    
    # Display classification report
    report = classification_report(Y_test_labels, predictions, target_names=['Negative', 'Positive'])
    st.text(report)

# Make predictions
st.subheader('🤔 Make a Prediction')
st.write("Enter a movie review to predict its sentiment:")
user_input = st.text_area('Enter a movie review:')
if st.button('Predict'):
    user_input_processed = preprocess_text(user_input)
    seq = tokenizer.texts_to_sequences([user_input_processed])
    padded = pad_sequences(seq, maxlen=X.shape[1])
    prediction = model.predict(padded)
    sentiment = np.argmax(prediction, axis=1)
    if sentiment == 0:
        st.write('Sentiment: 😡 Negative Review')
    else:
        st.write('Sentiment: 😀 Positive Review')


